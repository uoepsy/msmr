use this directory to create lecture content
